//
// Created by User on 22/06/2021.
//

#ifndef EX3_BOATS_SIMULATION_VIEW_H
#define EX3_BOATS_SIMULATION_VIEW_H


class View {
public:
    void Default();
    void size(int n);
    void zoom(double);
    void pan(double x, double y);
    void show();
};


#endif //EX3_BOATS_SIMULATION_VIEW_H
