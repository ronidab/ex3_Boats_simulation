#include <iostream>
using namespace std;
/******************************/
//TODO: run tests for:
//1.
/******************************/
void view_main()	{

	cout << "FROM VIEW MAIN!" << endl;

}
