#include <iostream>
using namespace std;
/******************************/
//TODO: run tests for:
//1.
/******************************/
void controller_main()	{

	cout << "FROM CONTROLLER MAIN!" << endl;

}
