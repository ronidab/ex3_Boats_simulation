
#include "Model.h"
#include "freighterBoat.h"
#include "cruiserBoat.h"
#include "patrolBoat.h"
/******************************/
//TODO: run tests for:
//2.	freighter and patrol boat class - for some reason these are not known in the file. check cause!
//3.	port class (check scenarion for updating).
/******************************/
void model_main() {

    freighterBoat f("emma", );



    //freighterBoat emma(4,4);
    //patrolBoat charlie();

}
