
#include "gameObj.h"
#include "Boat.h"
#include "Port.h"
/*****************/
// this file was generated for includings issues only.
/*****************/
gameObj::gameObj():update_ready(false)	{}
